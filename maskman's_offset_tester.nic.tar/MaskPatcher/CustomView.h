//
//  CustomView.h
//  CustomViewTest
//
//  Created by maskman on 6/27/19.
//  Copyright © 2019 maskman. All rights reserved.
//

#ifndef CustomView_h
#define CustomView_h
#import <UIKit/UIKit.h>
#import "WriteView.h"
#import "LogView.h"
@interface CustomView : UIView
- (void)showView;
@end

#endif /* CustomView_h */
